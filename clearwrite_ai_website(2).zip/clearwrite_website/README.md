# ClearWrite

A simple one-button AI writing improver. It corrects spelling, punctuation and grammar, then expands writing in a natural, not-too-formal style.

## Run it

1. Install Node.js (ask a parent/guardian or teacher to help if needed).
2. Open a terminal in this folder and run: `npm install`
3. Make a file named `.env` in this folder containing:

   `OPENAI_API_KEY=your_api_key_here`

   Keep this key private. Do not put it in the HTML file, share it, or upload the `.env` file. If you do not have an API key, ask a parent/guardian or teacher to help with the setup.
4. Run: `npm start`
5. Open `http://localhost:3000` in your browser.

The API key stays on the server and is not sent to the browser. API usage may cost money, so get an adult's permission and check the account's billing before using it.

## Files

- `public/index.html` — the website
- `server.js` — secure server-side AI request
- `package.json` — required packages

The AI can improve wording, but it can still make mistakes. Check any added factual details against reliable sources.
