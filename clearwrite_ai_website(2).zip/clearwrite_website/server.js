import "dotenv/config";
import express from "express";
import OpenAI from "openai";

const app = express();
const port = process.env.PORT || 3000;
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.use(express.json({ limit: "30kb" }));
app.use(express.static("public"));

app.post("/api/improve", async (req, res) => {
  const text = typeof req.body?.text === "string" ? req.body.text.trim() : "";
  if (!text) return res.status(400).json({ error: "Please enter some writing." });
  if (text.length > 12000) return res.status(400).json({ error: "Please keep your text under 12,000 characters." });

  try {
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5",
      instructions: `You are ClearWrite, a friendly writing improver for school-age users.
Rewrite the user's text in clear, natural, slightly expanded English.
Correct spelling, punctuation, grammar and awkward phrasing.
Make it more interesting by adding sensible explanation, context or examples that naturally follow from the original.
Aim for the style of this example:
Input: "like this in 1899 a strict new victorian law forced every child to stay in school until they turned 12"
Output: "In 1899, a new Victorian law was introduced that meant every child had to remain in school until the age of 12. This was a major change at the time, as it made education compulsory for longer and meant that children could no longer leave school at a younger age."
Keep the tone natural, clear and not too formal. Do not use fancy or robotic vocabulary. Usually make the result around 1.5 to 2 times longer when there is enough useful material, but do not pad it.
Preserve the user's meaning. Do not invent specific dates, names, statistics, quotations or historical claims. If extra factual detail is uncertain, explain the idea generally rather than making up facts.
Return only the improved writing, with no introduction, bullet list, explanation or quotation marks.`,
      input: text
    });
    res.json({ improved: response.output_text });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "The writing helper couldn't respond. Check the server setup and try again." });
  }
});

app.listen(port, () => console.log(`ClearWrite is running at http://localhost:${port}`));
